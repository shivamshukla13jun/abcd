import React, { useState, useEffect } from 'react';
import { Grid, TextField, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import apiService from '@/service/apiService';
import CustomDatePicker from '@/components/common/CommonDatePicker';
import dayjs from 'dayjs';

const CustomerSection = ({ register, errors, watch, setValue }) => {
  console.log("errors",errors)
  const [terms, setTerms] = useState([]);
  useEffect(() => {
    const fetchTerms = async () => {
      const response = await apiService.getPaymentTerms();
      setTerms(response.data);
    };
    fetchTerms();
  }, []);
  
  useEffect(() => {
    const selectedTerm = terms.find(term => term._id === watch('terms'));
    if (selectedTerm) {
      const dueDate = dayjs(watch('invoiceDueDate')).add(selectedTerm.days, 'day').format('YYYY-MM-DD');
      setValue('invoiceDueDate', dueDate);
    }
  }, [watch('terms')]);

  const handleCHangeDueDate = (e) => {
    if(watch('terms')){
      const selectedTerm = terms.find(term => term._id === watch('terms'));
      const dueDate = dayjs(e.target.value).add(selectedTerm.days, 'day').format('YYYY-MM-DD');
      setValue('invoiceDueDate', dueDate);
      return 
    }
    setValue('invoiceDueDate', e.target.value);
  };

  return (
    <Grid item xs={12}>
      <Grid container spacing={3}>
        <Grid item md={6}>
          <TextField
            fullWidth
            label="Customer Email"
            type="email"
            {...register('customerEmail')}
            error={!!errors.customerEmail}  
            helperText={errors.customerEmail?.message}
            InputProps={{ readOnly: true }}
            InputLabelProps={{ shrink: true }}
            placeholder="Customer email will auto-fill"
          />
        </Grid>
        <Grid item md={6}>
          <FormControl fullWidth>
            <InputLabel>Payment Options</InputLabel>
            <Select
              {...register('paymentOptions')}
              aria-hidden={false}
              label="Payment Options"
              defaultValue=""
              InputLabelProps={{ shrink: true }}
            >
              <MenuItem value="">Select payment option</MenuItem>
              <MenuItem value="Credit Card">Credit Card</MenuItem>
              <MenuItem value="Cash">Cash</MenuItem>
              <MenuItem value="Check">Check</MenuItem>
              <MenuItem value="Wire">Wire</MenuItem>
            </Select> 
            
          </FormControl>
        </Grid>
        <Grid item md={6}>
          <CustomDatePicker
            label="Invoice Date"
            placeholder='Enter invoice date'
            name="invoiceDate"
            register={register}
            value={watch('invoiceDate')}
            onChange={register('invoiceDate').onChange}
            errors={errors}
          />
          {errors.invoiceDate && <p className="error">{errors.invoiceDate.message}</p>}
        </Grid>
        <Grid item md={6}>
          <CustomDatePicker
            label="Invoice Due Date"
            placeholder='Enter invoice due date'
            name="invoiceDueDate"
            register={register}
            value={watch('invoiceDueDate')}
            onChange={handleCHangeDueDate}
            errors={errors}
          />
          {errors.invoiceDueDate && <p className="error">{errors.invoiceDueDate.message}</p>}
        </Grid>
        <Grid item md={6}>
          <TextField
            fullWidth
            label="Location"
            type="text"
            {...register('location')}
            error={!!errors.location}
            helperText={errors.location?.message}
            InputLabelProps={{ shrink: true }}
          />  
        </Grid>
        <Grid item md={6}>
          <FormControl fullWidth>
            <InputLabel>Terms</InputLabel>
            <Select
              {...register('terms')}
              aria-hidden={false}
              label="Terms"
              defaultValue=""
              InputLabelProps={{ shrink: true }}
            >
              <MenuItem value="">Select Terms</MenuItem>
              {terms.map((term) => (
                <MenuItem key={term._id} value={term._id}>
                  {term.name}
                </MenuItem>
              ))}
            </Select>
            {errors.terms && <p className="error">{errors.terms.message}</p>}
          </FormControl>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default CustomerSection;