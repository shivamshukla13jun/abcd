export const initialCustomerData = 
    {
        customerName: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        mcNumber: '',
        usdot: '',
        paymentMethod: '',
        paymentTerms: '',
        vatNumber: '',
        utrNumber: '',
      }
