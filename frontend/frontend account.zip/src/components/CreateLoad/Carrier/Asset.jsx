import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IoIosAdd, IoIosTrash } from "react-icons/io";
import {
  Button,
  Grid,
  Typography,
  Box,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Card,
  CardContent,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import { useCarrierModal } from "@/hooks/useCarrierModal";
import { setcarrierIds } from "@/redux/Slice/loadSlice";

const Asset = ({ index, onRemove }) => {
  const dispatch = useDispatch();
  const carrierData = useSelector((state) => state.load.carrierIds[index]); // Get Redux state
  const [carriers, setCarriers] = useState([]);
  const [assignDrivers, setAssignDrivers] = useState(carrierData?.assignDrivers || []);
  const [selectedCarrier, setSelectedCarrier] = useState(carrierData?.carrier || null);
  const [loading, setLoading] = useState(false);

  const { fetchCarriers } = useCarrierModal(setCarriers, setLoading);

  useEffect(() => {
    fetchCarriers(setCarriers, setLoading);
  }, []);

  const ChangeCarrier = (e) => {
    const carrierId = e.target.value;
    if (!carrierId) {
      setSelectedCarrier(null);
      setAssignDrivers([]);
    } else {
      const carrier = carriers.find((item) => item._id === carrierId);
      setSelectedCarrier(carrier);
      setAssignDrivers([]); // Reset assigned drivers
      dispatch(setcarrierIds({ index, asset: { carrier, assignDrivers: [] } }));
    }
  };

  const AddDriver = (driver) => {
    // Check if driver is already assigned
    if (!assignDrivers.some((d) => d._id === driver._id)) {
      const updatedDrivers = [...assignDrivers, driver];
      setAssignDrivers(updatedDrivers);
      dispatch(setcarrierIds({ index, asset: { carrier: selectedCarrier, assignDrivers: updatedDrivers } }));
    }
  };
  // Function to remove a driver from the assigned list
const removeDriver = (driverId) => {
  const updatedDrivers = assignDrivers.filter((driver) => driver._id !== driverId);
  setAssignDrivers(updatedDrivers);

  // Update Redux store
  dispatch(setcarrierIds({
    index,
    asset: {
      carrier: selectedCarrier,
      assignDrivers: updatedDrivers,
    }
  }));
};


  return (
    <div className="pickup-location-container mb-4 p-3 border rounded">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h6">Carrier {index + 1}</Typography>
        {onRemove && (
          <Button variant="outlined" color="error" startIcon={<IoIosTrash />} onClick={() => onRemove(index)} size="small">
            Remove
          </Button>
        )}
      </Box>

      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControl fullWidth>
            <InputLabel>Select Carrier</InputLabel>
            <Select value={selectedCarrier?._id || ""} onChange={ChangeCarrier}>
              <MenuItem disabled value="">Select Carrier</MenuItem>
              {carriers.map((carrier) => (
                <MenuItem key={carrier._id} value={carrier._id}>
                  {carrier.companyName} - {carrier.mcNumber}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      {/* Carrier Details & Drivers Section */}
      {selectedCarrier && (
        <Box mt={2}>
          <Card>
            <CardContent>
              <Typography variant="h6">Carrier Details</Typography>
              <Typography><b>Company Name:</b> {selectedCarrier.companyName}</Typography>
              <Typography><b>MC Number:</b> {selectedCarrier.mcNumber}</Typography>

              <Box mt={2}>
                <Typography variant="h6">Available Drivers</Typography>
                {selectedCarrier.drivers && selectedCarrier.drivers.length > 0 ? (
                  selectedCarrier.drivers.map((driver, idx) => (
                    <Card variant="outlined" key={idx} sx={{ mt: 1, p: 1 }}>
                      <Typography><b>Driver {idx + 1}:</b> {driver.driverName}</Typography>
                      <Typography><b>Phone:</b> {driver.phone}</Typography>
                      <Button variant="outlined" color="primary" size="small" onClick={() => AddDriver(driver)}>
                        Assign Driver
                      </Button>
                    </Card>
                  ))
                ) : (
                  <Typography>No drivers available</Typography>
                )}
              </Box>

             {/* Assigned Drivers List with Remove Option */}
<Box mt={2}>
  <Typography variant="h6">Assigned Drivers</Typography>
  {assignDrivers.length > 0 ? (
    assignDrivers.map((driver, idx) => (
      <Card variant="outlined" key={idx} sx={{ mt: 1, p: 1, display: "flex", justifyContent: "space-between" }}>
        <Box>
          <Typography><b>Driver {idx + 1}:</b> {driver.driverName}</Typography>
          <Typography><b>Phone:</b> {driver.phone}</Typography>
        </Box>
        <Button
          variant="outlined"
          color="error"
          size="small"
          startIcon={<IoIosTrash />}
          onClick={() => removeDriver(driver._id)}
        >
          Remove
        </Button>
      </Card>
    ))
  ) : (
    <Typography>No drivers assigned</Typography>
  )}
</Box>

            </CardContent>
          </Card>
        </Box>
      )}
    </div>
  );
};

export default Asset;
