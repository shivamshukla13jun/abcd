export const TAX_OPTIONS = [
  { id: 1, name: 'GST', rate: 5 },
  { id: 2, name: 'VAT', rate: 12.5 },
  { id: 3, name: 'Sales Tax', rate: 8 },
];

export const initialInvoiceData = {
  // ... your initial data
}; 