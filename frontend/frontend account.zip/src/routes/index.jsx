import Carriers from '@/pages/Carriers';

const routes = [
  // ... existing routes ...
  {
    path: '/carriers',
    element: <Carriers />,
  },
];

export default routes; 