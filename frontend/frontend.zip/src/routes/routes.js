import { lazy } from 'react';
import { Navigate } from 'react-router-dom';

// Lazily import components
const Dashboard = lazy(() => import('@pages/DashBoard'));
const CreateLoad = lazy(() => import('@pages/Load/CreateLoad'));
const ViewLoad = lazy(() => import('@pages/Load/ViewLoad'));
const EditLoad = lazy(() => import('@pages/EditLoad/EditLoad'));
const Customers = lazy(() => import('@pages/Customers/ViewCustomers'));
const Documents = lazy(() => import('@pages/Documents/ViewDocuments'));
const Login = lazy(() => import('@pages/AuthService/Login'));
const Register = lazy(() => import('@pages/AuthService/Register'));
const ForgetPassword = lazy(() => import('@pages/AuthService/ForgetPassword'));

// Route configurations
export const publicRoutes = [
  {
    path: '/login',
    element: Login,
  },
  {
    path: '/register',
    element: Register,
  },
  {
    path: '/forgot-password',
    element: ForgetPassword,
  },
];

export const protectedRoutes = [
  {
    path: '/',
    element: Dashboard,
    title: 'Dashboard',
    icon: 'dashboard',
  },
  {
    path: '/loads',
    element: ViewLoad,
    title: 'Loads',
    icon: 'truck',
  },
  {
    path: '/createload',
    element: CreateLoad,
    title: 'Create Load',
    icon: 'plus',
    hideInMenu: true,
  },
  {
    path: '/editload/:loadId',
    element: EditLoad,
    title: 'Edit Load',
    icon: 'edit',
    hideInMenu: true,
  },
  {
    path: '/customers',
    element: Customers,
    title: 'Customers',
    icon: 'users',
  },
  {
    path: '/documents',
    element: Documents,
    title: 'Documents',
    icon: 'file',
  },
];

// Auth wrapper components
const AuthenticatedRoute = ({ children }) => {
  return children;
};

const ProtectedRoute = ({ children }) => {
  return children;
};

export { AuthenticatedRoute, ProtectedRoute };
