import React, { Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { publicRoutes, protectedRoutes } from './routes';
import Layout from '@components/common/Layout';

const LoadingFallback = () => (
  <div className="page-loader">
    <div className="spinner-border text-primary" role="status">
      <span className="visually-hidden">Loading...</span>
    </div>
  </div>
);

// Auth wrapper components
const AuthenticatedRoute = ({ children }) => {
  const { isAuthenticated } = useSelector(state => state.user);
  return isAuthenticated ? <Navigate to="/" /> : children;
};

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useSelector(state => state.user);
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const RouterConfig = () => {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Routes>
        {/* Public Routes */}
        {publicRoutes.map(({ path, element: Element }) => (
          <Route
            key={path}
            path={path}
            element={
              <AuthenticatedRoute>
                <Suspense fallback={<LoadingFallback />}>
                  <Element />
                </Suspense>
              </AuthenticatedRoute>
            }
          />
        ))}

        {/* Protected Routes */}
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          {protectedRoutes.map(route => {
            if (route.children) {
              return route.children.map(child => (
                <Route
                  key={child.path}
                  path={child.path}
                  element={
                    <Suspense fallback={<LoadingFallback />}>
                      <child.element />
                    </Suspense>
                  }
                />
              ));
            }
            return (
              <Route
                key={route.path}
                path={route.path}
                element={
                  <Suspense fallback={<LoadingFallback />}>
                    <route.element />
                  </Suspense>
                }
              />
            );
          })}

          {/* Catch all route - redirect to dashboard */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Suspense>
  );
};

export default RouterConfig;
