import api from "@utils/axiosInterceptor";

const apiService = {
  login: async (userData) => {
    const response = await api.post("/auth/login", userData);
    return response.data;
  },
  // customer service
  getCustomers: async () => {
    const response = await api.get("/loads/customers");
    return response.data;
  },
  getCustomer: async (id) => {
    const response = await api.get(`/loads/customers/${id}`);
    return response.data;
  },
  createCustomer: async (customerData) => {
    const response = await api.post("/loads/customers", customerData);
    return response.data;
  },
  updateCustomer: async (id, customerData) => {
    const response = await api.put(`/loads/customers/${id}`, customerData);
    return response.data;
  },
  deleteCustomer: async (id) => {
    const response = await api.delete(`/loads/customers/${id}`);
    return response.data;
  },
  // asset service
  getAssets: async () => {
    const response = await api.get("/loads/assets");
    return response.data;
  },
  getAsset: async (id) => {
    const response = await api.get(`/loads/assets/${id}`);
    return response.data;
  },
  createAsset: async (assetData) => {
    const response = await api.post("/loads/assets", assetData);
    return response.data;
  },
  updateAsset: async (id, assetData) => {
    const response = await api.put(`/loads/assets/${id}`, assetData);
    return response.data;
  },
  deleteAsset: async (id) => {
    const response = await api.delete(`/loads/assets/${id}`);
    return response.data;
  },
  // Carriers Service
  getCarriers: async () => {
    const response = await api.get("/loads/carriers");
    return response.data;
  },
  getCarrier: async (id) => {
    const response = await api.get(`/loads/carriers/${id}`);
    return response.data;
  },
  createCarrier: async (carrierData) => {
    const response = await api.post("/loads/carriers", carrierData);
    return response.data;
  },
  updateCarrier: async (id, carrierData) => {
    const response = await api.put(`/loads/carriers/${id}`, carrierData);
    return response.data;
  },
  deleteCarrier: async (id) => {
    const response = await api.delete(`/loads/carriers/${id}`);
    return response.data;
  },
  createDriver: async (driverData) => {
    const response = await api.post("/loads/drivers", driverData);
    return response.data;
  },
  getDrivers: async () => {
    const response = await api.get("/loads/drivers");
    return response.data;
  },
  getDriver: async (id) => {
    const response = await api.get(`/loads/drivers/${id}`);
    return response.data;
  },
  updateDriver: async (id, driverData) => {
    const response = await api.put(`/loads/drivers/${id}`, driverData);
    return response.data;
  },
  deleteDriver: async (id) => {
    const response = await api.delete(`/loads/drivers/${id}`);
    return response.data;
  },
  getLocations: async (type="") => {
    const response = await api.get(`/loads/locations?type=${type}`);
    return response.data;
  },
  getLocation: async (id) => {
    const response = await api.get(`/loads/locations/${id}`);
    return response.data;
  },
  createLocation: async (locationData) => {
    const response = await api.post("/loads/locations", locationData);
    return response.data;
  },
  updateLocation: async (id, locationData) => {
    const response = await api.put(`/loads/locations/${id}`, locationData);
    return response.data;
  },
  deleteLocation: async (id) => {
    const response = await api.delete(`/loads/locations/${id}`);
    return response.data;
  },

  
  // load service
  getLoads: async (status="") => {
    const response = await api.get("/loads?status="+status);
    return response.data;
  },
  getLoad: async (id) => {
    const response = await api.get(`/loads/${id}`);
    return response.data;
  },
  createLoad: async (formData) => {
    const response = await api.post("/loads", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      }
    });
    return response.data;
  },
  updateLoad: async (id, formData) => {
    const response = await api.put(`/loads/${id}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      }
    });
    return response.data;
  },
  deleteLoad: async (id) => {
    const response = await api.delete(`/loads/${id}`);
    return response.data;
  },
  // getdatabyusdotnumber
  getDataByUsdotNumber: async (usdotNumber) => {
    const response = await api.get(`/safer-service/usdot/${usdotNumber}`);
    return response.data;
  },
  
};

export default apiService;
