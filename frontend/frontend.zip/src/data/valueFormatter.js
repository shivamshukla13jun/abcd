export function valueFormatter(value) {
    return `${value}mm`;
  }