
export const navData = [
  {
    title: "Dashboard",
    path: "/",
    icon: "FaTachometerAlt",
  },
  {
    title: "Loads",
    path: "/loads",
    icon: "FaTruck",
  },
  {
    title: "Customers",
    path: "/customers",
    icon: "FaUsers",
  },
  {
    title: "Doc Management",
    path: "/doc-management",
    icon: "FaFileAlt",
  },
  {
    title: "Accounting",
    path: "/accounting",
    icon: "FaMoneyBillWave",
    children: [
      {
        title: "Setup",
        path: "/accounting/setup",
      },
      {
        title: "Reports",
        path: "/accounting/reports",
      },
    ],
  },
];
