import React from 'react'
import AdminSidebar from '../compnents/common/AdminSidebar'
import TopBar from '../compnents/common/TopBar'

const Report = () => {
  return (
    <div id="wrapper">
    {/* Sidebar */}
 <AdminSidebar/>
    {/* End of Sidebar */}
    {/* Content Wrapper */}
    <div id="content-wrapper" className="d-flex flex-column">
      {/* Main Content */}
      <div id="content">
        {/* Topbar */}
         <TopBar/>
        {/* End of Topbar */}
        {/* Begin Page Content */}
        <div className="container-fluid">
          {/* Page Heading */}
          <div className="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
              Account Reports
            </h1>
          </div>
          <div className="row">
            {/* Content Column */}
            <div className="col-lg-12 mb-4">
              <div className="card shadow mb-4">
                <div className="table-tabs pt-4 px-3 pb-2 d-flex justify-content-between">
                  <ul className="nav nav-tabs" role="tablist">
                    <li className="nav-item">
                      <a
                        className="nav-link active"
                        data-toggle="tab"
                        href="#receivable"
                      >
                        Receivable
                      </a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" data-toggle="tab" href="#payable">
                        Payable
                      </a>
                    </li>
                  </ul>
                  {/*<div class="category-filter d-flex">
                        <select id="categoryFilter" class="form-control"> 
                          <option value="1">Carrier Company</option>
                          <option value="2">Repair Company</option>
                          <option value="3">Broker Company</option>
                        </select>
                      </div>*/}
                </div>
                <div className="tab-content table-tabs-content">
                  <div id="receivable" className="tab-pane active">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th>Company</th>
                              <th>Invoice</th>
                              <th>Invoice Date</th>
                              <th>Invoice Total</th>
                              <th>Paid</th>
                              <th className="bg-green-100">0-30</th>
                              <th className="bg-yellow-100">30-60</th>
                              <th className="bg-orange-100">60-90 </th>
                              <th className="bg-red-100">90+</th>
                              <th>Current</th>
                              <th>Rating</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Tiger Nixon</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2232</u>
                                </a>
                              </td>
                              <td>23-06-24</td>
                              <td>$4,500</td>
                              <td>$2,000</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$2,000</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$2,500</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Garrett Winters</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2242</u>
                                </a>
                              </td>
                              <td>23-06-24</td>
                              <td>$6,012</td>
                              <td>$6,012</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$6,012</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Ashton Cox</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2252</u>
                                </a>
                              </td>
                              <td>23-06-24</td>
                              <td>$1,500</td>
                              <td>$1,500</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$1,500</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Cedric Kelly</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2262</u>
                                </a>
                              </td>
                              <td>23-06-24</td>
                              <td>$7,182</td>
                              <td>$7,182</td>
                              <td className="bg-green-100">$7,182</td>
                              <td className="bg-yellow-100">$</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Airi Satou</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2272</u>
                                </a>
                              </td>
                              <td>23-06-24</td>
                              <td>$8,850</td>
                              <td>$3,000</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$</td>
                              <td className="bg-orange-100">$3,000</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$5,850</b>
                              </td>
                              <td>
                                3.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <div id="payable" className="tab-pane">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th>Company</th>
                              <th>Invoice</th>
                              <th>Invoice Date</th>
                              <th>Invoice Total</th>
                              <th>Paid</th>
                              <th className="bg-green-100">0-30</th>
                              <th className="bg-yellow-100">30-60</th>
                              <th className="bg-orange-100">60-90</th>
                              <th className="bg-red-100">90+</th>
                              <th>Current</th>
                              <th>Rating</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Nippon Express</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1045</u>
                                </a>
                              </td>
                              <td>22-06-24</td>
                              <td>$5,500</td>
                              <td>$3,000</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$3,000</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$2,500</b>
                              </td>
                              <td>
                                3.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Prime Inc.</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1044</u>
                                </a>
                              </td>
                              <td>21-06-24</td>
                              <td>$7,300</td>
                              <td>$6,012</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$6,012</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$1,288</b>
                              </td>
                              <td>
                                3.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>YRC Worldwide</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1043</u>
                                </a>
                              </td>
                              <td>20-06-24</td>
                              <td>$3,500</td>
                              <td>$3,500</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$3,500</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Schneider</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1042</u>
                                </a>
                              </td>
                              <td>17-06-24</td>
                              <td>$6,800</td>
                              <td>$6,050</td>
                              <td className="bg-green-100">$6,050</td>
                              <td className="bg-yellow-100">$</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                5.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td>Landstar Systems</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1041</u>
                                </a>
                              </td>
                              <td>15-06-24</td>
                              <td>$9,050</td>
                              <td>$9,050</td>
                              <td className="bg-green-100">$</td>
                              <td className="bg-yellow-100">$9,050</td>
                              <td className="bg-orange-100">$</td>
                              <td className="bg-red-100">$</td>
                              <td>
                                <b>$0.00</b>
                              </td>
                              <td>
                                4.0
                                <div className="ratingView">
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star checked" />
                                  <span className="fas fa-star" />
                                </div>
                              </td>
                              <td>
                                <button
                                  className="rew-btn"
                                  type="button"
                                  data-toggle="modal"
                                  data-target="#ratingModal"
                                >
                                  Write Review
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /.container-fluid */}
      </div>
      {/* End of Main Content */}
    </div>
    {/* End of Content Wrapper */}
  </div>
  
  )
}

export default Report