import React, { useState, useEffect } from 'react';
import { Button, Tab, Nav } from 'react-bootstrap';
import { IoIosAdd } from 'react-icons/io';
import { FaEdit } from 'react-icons/fa';
import AddCustomer from '@components/Customers/AddCustomer';
import EditCustomer from '@components/Customers/EditCustomer';
import apiService from '@service/apiService';
import './ViewCustomers.scss';

const CUSTOMER_TYPES = [
  { key: 'all', label: 'All Customers' },
  { key: 'Customer', label: 'Customer' },
  { key: 'Shipper', label: 'Shipper' },
  { key: 'Consignee', label: 'Consignee' },
  { key: 'Broker', label: 'Broker' }
];

const ViewCustomers = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [activeType, setActiveType] = useState('all');
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const response = await apiService.getCustomers();
      setCustomers(response.data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleEditClick = (customer) => {
    setSelectedCustomer(customer);
    setShowEditModal(true);
  };

  const handleEditSuccess = () => {
    fetchCustomers();
    setShowEditModal(false);
    setSelectedCustomer(null);
  };

  const handleAddSuccess = () => {
    fetchCustomers();
    setShowAddModal(false);
  };

  const filteredCustomers = activeType === 'all'
    ? customers
    : customers.filter(customer => customer.type === activeType);

  const getRatingClass = (rating) => {
    const ratingMap = {
      'A': 'rating-a',
      'B': 'rating-b',
      'C': 'rating-c',
      'D': 'rating-d',
      'F': 'rating-f'
    };
    return `customer-rating ${ratingMap[rating] || ''}`;
  };

  return (
    <div className="view-customers">
      <div className="view-customers__container">
        <div className="view-customers__header">
          <h2>Customers</h2>
          <Button className="view-customers__create-btn" onClick={() => setShowAddModal(true)}>
            <IoIosAdd />
            New Customer
          </Button>
        </div>

        <div className="view-customers__tabs">
          <Nav variant="tabs">
            {CUSTOMER_TYPES.map(type => (
              <Nav.Item key={type.key}>
                <Nav.Link
                  active={activeType === type.key}
                  onClick={() => setActiveType(type.key)}
                >
                  {type.label}
                </Nav.Link>
              </Nav.Item>
            ))}
          </Nav>
        </div>

        <div className="customer-table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Company Name</th>
                <th>Type</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>MC Number</th>
                <th>USDOT</th>
                <th>Rating</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map(customer => (
                <tr key={customer.id}>
                  <td>{customer.customerName}</td>
                  <td>{customer.type}</td>
                  <td>{customer.email}</td>
                  <td>{customer.phone}</td>
                  <td>{`${customer.city}, ${customer.state}`}</td>
                  <td>{customer.mcNumber}</td>
                  <td>{customer.usdot}</td>
                  <td>
                    <span className={getRatingClass(customer.rating)}>
                      {customer.rating || 'N/A'}
                    </span>
                  </td>
                  <td>
                    <Button
                      variant="link"
                      className="customer-action-btn"
                      onClick={() => handleEditClick(customer)}
                    >
                      <FaEdit />
                    </Button>
                  </td>
                </tr>
              ))}
              {filteredCustomers.length === 0 && (
                <tr>
                  <td colSpan="9" className="text-center py-4">
                    No customers found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AddCustomer
        show={showAddModal}
        onHide={() => setShowAddModal(false)}
        onSuccess={handleAddSuccess}
      />

      <EditCustomer
        show={showEditModal}
        onHide={() => {
          setShowEditModal(false);
          setSelectedCustomer(null);
        }}
        onSuccess={handleEditSuccess}
        customer={selectedCustomer}
      />
    </div>
  );
};

export default ViewCustomers;
