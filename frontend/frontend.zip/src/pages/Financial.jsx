import React from 'react'
import AdminSidebar from '../compnents/common/AdminSidebar'
import TopBar from '../compnents/common/TopBar'

const Financial = () => {
  return (
    <div id="wrapper">
    {/* Sidebar */}
 <AdminSidebar/>
    {/* End of Sidebar */}
    {/* Content Wrapper */}
    <div id="content-wrapper" className="d-flex flex-column">
      {/* Main Content */}
      <div id="content">
        {/* Topbar */}
    <TopBar/>
        {/* End of Topbar */}
        {/* Begin Page Content */}
        <div className="container-fluid">
          {/* Page Heading */}
          <div className="d-sm-flex align-items-center justify-content-between mb-3">
            <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
              Financial Details
            </h1>
          </div>
          <div className="row">
            {/* Content Column */}
            <div className="col-lg-12 mb-4">
              <div className="card shadow mb-4">
                <div className="card-body">
                  <div className="table-responsive">
                    <table
                      className="table table-bordered"
                      width="100%"
                      cellSpacing={0}
                    >
                      <thead>
                        <tr>
                          <th>Load ID</th>
                          <th>Load Amount</th>
                          <th>Lumper</th>
                          <th>Detention</th>
                          <th>Layover</th>
                          <th>Extra</th>
                          <th>Date</th>
                          <th className="text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#1041</td>
                          <td>$2,556</td>
                          <td>$256</td>
                          <td>$23</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>23-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1042</td>
                          <td>$5,456</td>
                          <td>$546</td>
                          <td>$42</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>22-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1043</td>
                          <td>$9,345</td>
                          <td>$446</td>
                          <td>$34</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>21-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1044</td>
                          <td>$10,500</td>
                          <td>$893</td>
                          <td>$17</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>20-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1045</td>
                          <td>$15,234</td>
                          <td>$340</td>
                          <td>$45</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>19-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1046</td>
                          <td>$12,456</td>
                          <td>$250</td>
                          <td>$55</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>18-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1047</td>
                          <td>$8,532</td>
                          <td>$445</td>
                          <td>$38</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>17-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1048</td>
                          <td>$6,000</td>
                          <td>$567</td>
                          <td>$23</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>16-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>#1053</td>
                          <td>$3,500</td>
                          <td>$450</td>
                          <td>$12</td>
                          <td>Nil</td>
                          <td>Nil</td>
                          <td>11-06-24</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editFinancial"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* End Create Load Form */}
        </div>
        {/* /.container-fluid */}
      </div>
      {/* End of Main Content */}
    </div>
    {/* End of Content Wrapper */}
  </div>
  
  )
}

export default Financial