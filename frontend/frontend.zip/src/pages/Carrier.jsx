import React from 'react'
import AdminSidebar from '../compnents/common/AdminSidebar'
import TopBar from '../compnents/common/TopBar'

const Carrier = () => {
  return (
    <div id="wrapper">
  {/* Sidebar */}
<AdminSidebar/>
  {/* End of Sidebar */}
  {/* Content Wrapper */}
  <div id="content-wrapper" className="d-flex flex-column">
    {/* Main Content */}
    <div id="content">
      {/* Topbar */}
    <TopBar/>
      {/* End of Topbar */}
      {/* Begin Page Content */}
      <div className="container-fluid">
        {/* Page Heading */}
        <div className="d-sm-flex align-items-center justify-content-between mb-3">
          <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
            Carrier Details
          </h1>
        </div>
        <div className="row">
          {/* Content Column */}
          <div className="col-lg-12 mb-4">
            <div className="card shadow mb-4">
              <div className="card-body">
                <div className="table-responsive">
                  <table
                    className="table table-bordered"
                    width="100%"
                    cellSpacing={0}
                  >
                    <thead>
                      <tr>
                        <th>Load ID</th>
                        <th>Carrier Co.</th>
                        <th>Truck No.</th>
                        <th>Trailer No.</th>
                        <th>Driver</th>
                        <th>Driver No.</th>
                        <th>LIC No.</th>
                        <th>Date</th>
                        <th className="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>#1041</td>
                        <td>Tiger Nixon</td>
                        <td>YYX-2244</td>
                        <td>B-23453</td>
                        <td>Diego</td>
                        <td>555999888</td>
                        <td>H-476-3345-8905</td>
                        <td>23-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1042</td>
                        <td>Garrett Winters</td>
                        <td>RTY-5678</td>
                        <td>W-90456</td>
                        <td>Anders</td>
                        <td>555859520</td>
                        <td>G-456-9087-4355</td>
                        <td>22-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1043</td>
                        <td>Ashton Cox</td>
                        <td>TYR-4563</td>
                        <td>G-23789</td>
                        <td>Brayden</td>
                        <td>698547258</td>
                        <td>F-345-5673-4565</td>
                        <td>21-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1044</td>
                        <td>Cedric Kelly</td>
                        <td>FGH-2345</td>
                        <td>R-56789</td>
                        <td>Marco</td>
                        <td>558265485</td>
                        <td>E-890-4567-7787</td>
                        <td>20-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1045</td>
                        <td>Airi Satou</td>
                        <td>GHJ-9878</td>
                        <td>F-90456</td>
                        <td>Akio</td>
                        <td>669885475</td>
                        <td>D-546-1234-5678</td>
                        <td>19-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1046</td>
                        <td>Brielle Williamson</td>
                        <td>SDF-5567</td>
                        <td>E-98765</td>
                        <td>Alexei</td>
                        <td>785265485</td>
                        <td>C-213-5678-6787</td>
                        <td>18-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1047</td>
                        <td>Herrod Chandler</td>
                        <td>QWE-8967</td>
                        <td>S-67832</td>
                        <td>Altair</td>
                        <td>235874568</td>
                        <td>B-545-6745-2345</td>
                        <td>17-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1048</td>
                        <td>Rhona Davidson</td>
                        <td>JJK-6789</td>
                        <td>Y-36532</td>
                        <td>Amir</td>
                        <td>458715885</td>
                        <td>B-534-5645-8945</td>
                        <td>16-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>#1053</td>
                        <td>Charde Marshall</td>
                        <td>KLJ-3465</td>
                        <td>T-23456</td>
                        <td>Steffan</td>
                        <td>556895258</td>
                        <td>A-234-4445-8906</td>
                        <td>11-06-24</td>
                        <td>
                          <div className="act-opt">
                            <ul>
                              <li>
                                <a
                                  href="javascript:void(0)"
                                  data-toggle="modal"
                                  data-target="#editCarrier"
                                >
                                  <i className="fas fa-edit" />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* End Create Load Form */}
      </div>
      {/* /.container-fluid */}
    </div>
    {/* End of Main Content */}
  </div>
  {/* End of Content Wrapper */}
</div>

  )
}

export default Carrier