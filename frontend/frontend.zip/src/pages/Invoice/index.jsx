import React from 'react'
import AdminSidebar from '../../compnents/common/AdminSidebar'
import TopBar from '../../compnents/common/TopBar'
import { Link } from 'react-router-dom'

const InVoice = () => {
  return (
    <div id="wrapper">
    {/* Sidebar */}
   <AdminSidebar/>
    {/* End of Sidebar */}
    {/* Content Wrapper */}
    <div id="content-wrapper" className="d-flex flex-column">
      {/* Main Content */}
      <div id="content">
        {/* Topbar */}
      <TopBar/>
        {/* End of Topbar */}
        {/* Begin Page Content */}
        <div className="container-fluid">
          {/* Page Heading */}
          <div className="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
              Invoices &amp; Bills
            </h1>
            <Link
              to="/createinvoice"
              className="btn btn-sm btn-primary shadow-sm px-3 py-2"
            >
              <i className="fas fa-plus fa-sm text-white-50" /> &nbsp;Create
              Invoice
            </Link>
          </div>
          <div className="row">
            {/* Content Column */}
            <div className="col-lg-12 mb-4">
              <div className="card shadow mb-4">
                <div className="table-tabs pt-4 px-3 pb-2">
                  <ul className="nav nav-tabs" role="tablist">
                    <li className="nav-item">
                      <a
                        className="nav-link active"
                        data-toggle="tab"
                        href="#brokerInvoice"
                      >
                        Broker Invoices
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className="nav-link"
                        data-toggle="tab"
                        href="#repairInvoice"
                      >
                        Repair Invoices
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className="nav-link"
                        data-toggle="tab"
                        href="#carrierInvoice"
                      >
                        Carrier Invoices
                      </a>
                    </li>
                  </ul>
                </div>
                <div className="tab-content table-tabs-content">
                  <div id="brokerInvoice" className="tab-pane active">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th>Load ID</th>
                              <th>Company</th>
                              <th>Invoice</th>
                              <th>Name</th>
                              <th>Contact </th>
                              <th>Email ID</th>
                              <th>Invoice Date</th>
                              <th className="text-center">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>#1041</td>
                              <td>Tiger Nixon</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2232</u>
                                </a>
                              </td>
                              <td>Diego</td>
                              <td>555999888</td>
                              <td>tiger@gmail.com</td>
                              <td>23-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1042</td>
                              <td>Garrett Winters</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2242</u>
                                </a>
                              </td>
                              <td>Anders</td>
                              <td>555859520</td>
                              <td>garrett@gmail.com</td>
                              <td>22-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1043</td>
                              <td>Ashton Cox</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2252</u>
                                </a>
                              </td>
                              <td>Brayden</td>
                              <td>698547258</td>
                              <td>ashton@gmail.com</td>
                              <td>21-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1044</td>
                              <td>Cedric Kelly</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2262</u>
                                </a>
                              </td>
                              <td>Marco</td>
                              <td>558265485</td>
                              <td>cedric@gmail.com</td>
                              <td>20-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1053</td>
                              <td>Airi Satou</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2272</u>
                                </a>
                              </td>
                              <td>Akio</td>
                              <td>669885475</td>
                              <td>airi@gmail.com</td>
                              <td>19-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <div id="repairInvoice" className="tab-pane">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th>Unit No.</th>
                              <th>Company</th>
                              <th>Invoice</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>Email ID</th>
                              <th>Invoice Date</th>
                              <th className="text-center">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>#5911</td>
                              <td>Colleen Hurst</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#1244</u>
                                </a>
                              </td>
                              <td>Hugo</td>
                              <td>555999888</td>
                              <td>hugo@gmail.com</td>
                              <td>23-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#5822</td>
                              <td>Sonya Frost</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2311</u>
                                </a>
                              </td>
                              <td>Orion</td>
                              <td>555859520</td>
                              <td>sonya@gmail.com</td>
                              <td>22-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#5733</td>
                              <td>Rhona Davidson</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#5467</u>
                                </a>
                              </td>
                              <td>Steffan</td>
                              <td>698547258</td>
                              <td>rhona@gmail.com</td>
                              <td>21-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#5644</td>
                              <td>Quinn Flynn</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#3456</u>
                                </a>
                              </td>
                              <td>Martin</td>
                              <td>558265485</td>
                              <td>quinn@gmail.com</td>
                              <td>20-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#5578</td>
                              <td>Charde Marshall</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#8902</u>
                                </a>
                              </td>
                              <td>Johny</td>
                              <td>669885475</td>
                              <td>johny@gmail.com</td>
                              <td>19-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <div id="carrierInvoice" className="tab-pane">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th>Load ID</th>
                              <th>Company</th>
                              <th>Invoice</th>
                              <th>Name</th>
                              <th>Contact No.</th>
                              <th>Email ID</th>
                              <th>Invoice Date</th>
                              <th className="text-center">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>#1041</td>
                              <td>Penske Logistics</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2232</u>
                                </a>
                              </td>
                              <td>Antonio</td>
                              <td>555999888</td>
                              <td>penske@gmail.com</td>
                              <td>23-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1042</td>
                              <td>U.S Express</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2242</u>
                                </a>
                              </td>
                              <td>Devin</td>
                              <td>555859520</td>
                              <td>express@gmail.com</td>
                              <td>22-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1043</td>
                              <td>Averitt Express</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2252</u>
                                </a>
                              </td>
                              <td>Altair</td>
                              <td>698547258</td>
                              <td>averitt@gmail.com</td>
                              <td>21-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1044</td>
                              <td>Evans Delivery</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2262</u>
                                </a>
                              </td>
                              <td>Alexei</td>
                              <td>558265485</td>
                              <td>evans@gmail.com</td>
                              <td>20-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>#1053</td>
                              <td>Sirva Inc.</td>
                              <td>
                                <a href="javascript:void(0)">
                                  <u>#2272</u>
                                </a>
                              </td>
                              <td>Akio</td>
                              <td>669885475</td>
                              <td>sirva@gmail.com</td>
                              <td>19-06-24</td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a href="#">
                                        <i className="fas fa-eye" />
                                      </a>
                                    </li>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        data-toggle="modal"
                                        data-target="#mailBroker"
                                      >
                                        <i className="fas fa-paper-plane" />
                                      </a>
                                    </li>
                                    <li>
                                      <div className="dropdown no-arrow">
                                        <a
                                          className="dropdown-toggle"
                                          href="#"
                                          role="button"
                                          id="dropdownMenuLink"
                                          data-toggle="dropdown"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v fa-sm fa-fw" />
                                        </a>
                                        <div
                                          className="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                          aria-labelledby="dropdownMenuLink"
                                        >
                                          <a className="dropdown-item" href="#">
                                            Download
                                          </a>
                                          <a className="dropdown-item" href="#">
                                            Edit
                                          </a>
                                          <a
                                            className="dropdown-item text-danger"
                                            href="#"
                                          >
                                            Delete
                                          </a>
                                        </div>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /.container-fluid */}
      </div>
      {/* End of Main Content */}
    </div>
    {/* End of Content Wrapper */}
  </div>
  
  )
}

export default InVoice