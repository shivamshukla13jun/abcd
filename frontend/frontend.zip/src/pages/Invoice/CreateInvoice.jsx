import React from 'react'
import AdminSidebar from '../../compnents/common/AdminSidebar'
import TopBar from '../../compnents/common/TopBar'

const CreateInvoice = () => {
  return (
    <div id="wrapper">
  {/* Sidebar */}
 <AdminSidebar/>
  {/* End of Sidebar */}
  {/* Content Wrapper */}
  <div id="content-wrapper" className="d-flex flex-column">
    {/* Main Content */}
    <div id="content">
      {/* Topbar */}
    <TopBar/>
      {/* End of Topbar */}
      {/* Begin Page Content */}
      <div className="container-fluid">
        {/* Page Heading */}
        <div className="d-sm-flex align-items-center justify-content-between mb-3">
          <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
            Create New Invoice
          </h1>
        </div>
        {/* Start Create Load Form */}
        <hr />
        <div className="row">
          <div className="col-lg-12">
            <div className="creatInvoice_template">
              <div className="row">
                <div className="col-md-10">
                  <form className="invoiceForm">
                    <div className="form-group row">
                      <div className="col-sm-3">
                        <label>Invoice No.</label>
                        <input
                          type="text"
                          className="form-control"
                          disabled=""
                          defaultValue="#2231"
                          required=""
                        />
                      </div>
                      <div className="col-sm-6">
                        <label>Shipping From</label>
                        <textarea
                          className="form-control h-auto"
                          rows={1}
                          cols={50}
                          required=""
                          defaultValue={
                            "5954 W Indianapolis Ave, Fresno, CA 93722, United States"
                          }
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Total Amount</label>
                        <div className="input-group">
                          <div className="input-group-prepend">
                            <div className="input-group-text">
                              <i className="fas fa-dollar-sign" />
                            </div>
                          </div>
                          <input
                            type="number"
                            className="form-control"
                            defaultValue={7568}
                            required=""
                          />
                        </div>
                      </div>
                    </div>
                    <div className="form-group row">
                      <div className="col-sm-3">
                        <label>Customer</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Customer Email</label>
                        <input
                          type="email"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Customer No.</label>
                        <input
                          type="tel"
                          className="form-control"
                          maxLength={10}
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label className="d-block">Online Payments</label>
                        <label className="radio-inline">
                          <input
                            type="radio"
                            name="optradio"
                            defaultChecked=""
                          />{" "}
                          Cards
                        </label>
                        <label className="radio-inline ml-2">
                          <input type="radio" name="optradio" /> Bank Transfer
                        </label>
                      </div>
                    </div>
                    <div className="form-group row">
                      <div className="col-sm-3">
                        <label>Billing Address</label>
                        <textarea
                          className="form-control h-auto"
                          rows={1}
                          cols={50}
                          required=""
                          defaultValue={""}
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Terms</label>
                        <select className="form-control" required="">
                          <option value={1}>Due on receipt</option>
                          <option value={2}>0-30 Days</option>
                          <option value={3}>30-60 Days</option>
                          <option value={4}>60-90 Days</option>
                          <option value={5}>90+ Days</option>
                        </select>
                      </div>
                      <div className="col-sm-3">
                        <label>Invoice Date</label>
                        <input
                          type="date"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Due Date</label>
                        <input
                          type="date"
                          className="form-control"
                          required=""
                        />
                      </div>
                    </div>
                    <div className="form-group row">
                      <div className="col-sm-3">
                        <label>Shipping To</label>
                        <textarea
                          className="form-control h-auto"
                          rows={1}
                          cols={50}
                          required=""
                          defaultValue={""}
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Ship via</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Shipping Date</label>
                        <input
                          type="date"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Tracking No.</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                    </div>
                    <div className="form-group row">
                      <div className="col-sm-3">
                        <label>VIN No.</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Lic Plate / State</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>DOT #</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                      <div className="col-sm-3">
                        <label>Unit #</label>
                        <input
                          type="text"
                          className="form-control"
                          required=""
                        />
                      </div>
                    </div>
                    <div className="form-group row">
                      <div className="col-sm-6">
                        <label>Note*</label>
                        <textarea
                          className="form-control h-auto"
                          rows={2}
                          cols={50}
                          placeholder="Invoice note..."
                          required=""
                          defaultValue={""}
                        />
                      </div>
                    </div>
                  </form>
                </div>
                <div className="col-md-2">
                  <div className="balance_due text-right">
                    <p className="mb-1">Balance Due</p>
                    <h2 className="due_payment font-weight-bolder">$550.98</h2>
                  </div>
                </div>
                <div className="col-md-12 mt-3">
                  <div className="card mb-5 border-0">
                    <div className="card-body p-0">
                      <div className="table-responsive add_parts_table">
                        <table
                          id="bill_table"
                          className="table table-bordered mb-0"
                          width="100%"
                          cellSpacing={0}
                        >
                          <thead>
                            <tr>
                              <th className="chck-sort text-center px-0">#</th>
                              <th width="250px">Product / Services</th>
                              <th>Description</th>
                              <th width="100px">Qty</th>
                              <th width="150px">Rate</th>
                              <th>Amount</th>
                              <th width="70px" className="text-center">
                                Tax
                              </th>
                              <th width="50px" />
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td />
                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  defaultValue="Parts:Brake"
                                />
                              </td>
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={2}
                                />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={65}
                                />
                              </td>
                              <td>130.00</td>
                              <td>
                                <i className="fas fa-check text-success fa-sm" />
                              </td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        onclick="deleteFunction(this);"
                                      >
                                        <i className="fas fa-trash-alt" />
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td />
                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  defaultValue="Parts:Drums"
                                />
                              </td>
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={2}
                                />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={100}
                                />
                              </td>
                              <td>200.00</td>
                              <td>
                                <i className="fas fa-check text-success fa-sm" />
                              </td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        onclick="deleteFunction(this);"
                                      >
                                        <i className="fas fa-trash-alt" />
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td />
                              <td>
                                <input
                                  type="text"
                                  className="form-control"
                                  defaultValue="Parts:Hub Caps"
                                />
                              </td>
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={1}
                                />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control"
                                  defaultValue={150}
                                />
                              </td>
                              <td>150.00</td>
                              <td>
                                <i className="fas fa-check text-success fa-sm" />
                              </td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        onclick="deleteFunction(this);"
                                      >
                                        <i className="fas fa-trash-alt" />
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td />
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input type="number" className="form-control" />
                              </td>
                              <td>
                                <input type="number" className="form-control" />
                              </td>
                              <td />
                              <td>
                                <i className="fas fa-check text-success fa-sm" />
                              </td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        onclick="deleteFunction(this);"
                                      >
                                        <i className="fas fa-trash-alt" />
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td />
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input type="text" className="form-control" />
                              </td>
                              <td>
                                <input type="number" className="form-control" />
                              </td>
                              <td>
                                <input type="number" className="form-control" />
                              </td>
                              <td />
                              <td>
                                <i className="fas fa-check text-success fa-sm" />
                              </td>
                              <td>
                                <div className="act-opt">
                                  <ul>
                                    <li>
                                      <a
                                        href="javascript:void(0)"
                                        onclick="deleteFunction(this);"
                                      >
                                        <i className="fas fa-trash-alt" />
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="row">
                        <div className="col-lg-5 col-sm-5 m-3 table_funct_btn">
                          <button
                            id="addnew_row"
                            type="button"
                            className="btn btn-secondary text-xs mr-1"
                          >
                            Add lines
                          </button>
                          <button
                            type="button"
                            className="btn btn-secondary text-xs"
                          >
                            Add subtotal
                          </button>
                          <div className="form-group row mt-5">
                            <div className="col-sm-12">
                              <label>Message on invoice</label>
                              <textarea
                                className="form-control h-auto"
                                rows={4}
                                cols={50}
                                required=""
                                defaultValue={""}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="table-responsive subtotal_table col-lg-3 col-sm-5 ml-auto">
                          <table className="table table-clear">
                            <tbody>
                              <tr>
                                <td className="text-right">Subtotal</td>
                                <td className="text-right">
                                  <strong>$480.00</strong>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-right">
                                  <select className="form-control" required="">
                                    <option value="">Discount Percent</option>
                                    <option value={2}>5%</option>
                                    <option value={3}>10%</option>
                                    <option value={4}>20%</option>
                                    <option value={5}>30%</option>
                                  </select>
                                </td>
                                <td className="text-right" width="120px">
                                  <strong>$70.98</strong>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-right">
                                  <select className="form-control" required="">
                                    <option value="">Select Tax Rate</option>
                                    <option value={2}>5%</option>
                                    <option value={3}>10%</option>
                                    <option value={4}>20%</option>
                                    <option value={5}>30%</option>
                                  </select>
                                </td>
                                <td className="text-right" width="120px">
                                  <strong>$0.00</strong>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-right">Shipping</td>
                                <td className="text-right">
                                  <input
                                    type="text"
                                    className="form-control"
                                    required=""
                                  />
                                </td>
                              </tr>
                              <tr>
                                <td className="text-right">
                                  <strong>Total</strong>
                                </td>
                                <td className="text-right">
                                  <strong>$550.98</strong>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-right">
                                  <strong>Balance due</strong>
                                </td>
                                <td className="text-right">
                                  <strong>$550.98</strong>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-12 invoice_sidebar mt-3 mb-3 text-right">
                          <button
                            type="button"
                            className="btn btn-danger px-3 py-1 mr-1"
                          >
                            <i className="fas fa-paper-plane fa-sm" />
                            &nbsp;Send Invoice
                          </button>
                          <button
                            type="button"
                            className="btn px-3 py-1 bg-gray-700 text-white mr-1"
                          >
                            &nbsp;Preview
                          </button>
                          <button
                            type="button"
                            className="btn btn-primary px-4 py-1"
                          >
                            &nbsp;Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* End Create Load Form */}
      </div>
      {/* /.container-fluid */}
    </div>
    {/* End of Main Content */}
  </div>
  {/* End of Content Wrapper */}
</div>

  )
}

export default CreateInvoice