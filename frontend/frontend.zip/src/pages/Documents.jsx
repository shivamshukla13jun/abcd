import React from 'react'

const Documents = () => {
  return (
    <div id="wrapper">
 
    {/* End of Sidebar */}
    {/* Content Wrapper */}
    <div id="content-wrapper" className="d-flex flex-column">
      {/* Main Content */}
      <div id="content">

        {/* End of Topbar */}
        {/* Begin Page Content */}
        <div className="container-fluid">
          {/* Page Heading */}
          <div className="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 className="h5 mb-0 text-gray-800 font-weight-bolder">
              Bills &amp; Documents
            </h1>
            <button
              type="button"
              data-toggle="modal"
              data-target="#uploadDoc"
              className="btn btn-sm btn-primary shadow-sm px-4 py-2"
            >
              <i className="fas fa-upload fa-sm text-white-50" /> &nbsp; Upload
              New Document
            </button>
          </div>
          <div className="row">
            {/* Content Column */}
            <div className="col-lg-12 mb-4">
              <div className="card shadow mb-4">
                <div className="card-body">
                  <div className="table-responsive">
                    <table
                      className="table table-bordered"
                      width="100%"
                      cellSpacing={0}
                    >
                      <thead>
                        <tr>
                          <th className="chck-sort text-center px-0">#</th>
                          <th>Load ID</th>
                          <th>Document Name</th>
                          <th>Description</th>
                          <th>Upload Source</th>
                          <th>Upload Date</th>
                          <th>Status</th>
                          <th className="text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="chck">
                            <input type="checkbox" />
                          </td>
                          <td>#1041</td>
                          <td>Bill of Loading</td>
                          <td className="doc_desc">
                            <span>
                              It is a long established fact that a reader will be
                              distracted by the readable content{" "}
                            </span>
                          </td>
                          <td>System Generated</td>
                          <td>23-06-24</td>
                          <td>Generated</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editDocuments"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadfileDownload"
                                  >
                                    <i className="fas fa-download" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadDelete"
                                  >
                                    <i className="fas fa-trash-alt" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td className="chck">
                            <input type="checkbox" />
                          </td>
                          <td>#1042</td>
                          <td>Loading Bills</td>
                          <td className="doc_desc">
                            <span>
                              Reader will be distracted by the readable content
                            </span>
                          </td>
                          <td>System Generated</td>
                          <td>22-06-24</td>
                          <td>Generated</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editDocuments"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadfileDownload"
                                  >
                                    <i className="fas fa-download" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadDelete"
                                  >
                                    <i className="fas fa-trash-alt" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td className="chck">
                            <input type="checkbox" />
                          </td>
                          <td>#1043</td>
                          <td>NFL Bills</td>
                          <td className="doc_desc">
                            <span>
                              It is a long established fact that a reader will be
                              distracted by the readable content
                            </span>
                          </td>
                          <td>System Generated</td>
                          <td>21-06-24</td>
                          <td>Generated</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editDocuments"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadfileDownload"
                                  >
                                    <i className="fas fa-download" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadDelete"
                                  >
                                    <i className="fas fa-trash-alt" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td className="chck">
                            <input type="checkbox" />
                          </td>
                          <td>#1044</td>
                          <td>TXL Bills</td>
                          <td className="doc_desc">
                            <span>
                              It is a long established fact that a reader will be
                              distracted by the readable content
                            </span>
                          </td>
                          <td>System Generated</td>
                          <td>20-06-24</td>
                          <td>Generated</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editDocuments"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadfileDownload"
                                  >
                                    <i className="fas fa-download" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadDelete"
                                  >
                                    <i className="fas fa-trash-alt" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td className="chck">
                            <input type="checkbox" />
                          </td>
                          <td>#1053</td>
                          <td>Fresno Load Bills</td>
                          <td className="doc_desc">
                            <span>
                              It is a long established fact that a reader will be
                              distracted by the readable content
                            </span>
                          </td>
                          <td>System Generated</td>
                          <td>11-06-24</td>
                          <td>Generated</td>
                          <td>
                            <div className="act-opt">
                              <ul>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#editDocuments"
                                  >
                                    <i className="fas fa-edit" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadfileDownload"
                                  >
                                    <i className="fas fa-download" />
                                  </a>
                                </li>
                                <li>
                                  <a
                                    href="javascript:void(0)"
                                    data-toggle="modal"
                                    data-target="#loadDelete"
                                  >
                                    <i className="fas fa-trash-alt" />
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /.container-fluid */}
      </div>
      {/* End of Main Content */}
    </div>
    {/* End of Content Wrapper */}
  </div>
  
  )
}

export default Documents