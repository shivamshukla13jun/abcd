import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { addToast } from '@redux/Slice/toastSlice';  // Assuming you have toastSlice for toast messages

const baseQuery = fetchBaseQuery({
  baseUrl: import.meta.env.VITE_API_URL, // Adjust base URL
  // credentials: 'include', // Ensure cookies are sent with each request
});

const baseQueryWithRefresh = async (args, api, extraOptions) => {
  try {
    // Perform the base query
    const result = await baseQuery(args, api, extraOptions);

    // Check if the response is successful
    if (result.error && result.error.status === 401) {
      // If the error is a 401 (Unauthorized), try refreshing the token
      const refreshResult = await baseQuery({
        url: '/auth/refresh-token',  // Assuming you have a route for refreshing the token
        method: 'POST',
      }, api, extraOptions);

      if (refreshResult.data) {
        // If refresh is successful, retry the original request with the new access token
        return baseQuery(args, api, extraOptions);
      } else {
        // If refresh failed, handle logout or redirection to login page
        api.dispatch(addToast({ message: 'Session expired. Please log in again.', type: 'error' }));
        return { error: { status: 401, message: 'Session expired' } };
      }
    }

    return result;
  } catch (error) {
    return { error: error.message || 'An unknown error occurred' };
  }
};

export const apiSlice = createApi({
  reducerPath: "api",
  baseQuery: baseQueryWithRefresh, // Use the custom base query with refresh logic
  endpoints: (builder) => ({
    getUsers: builder.query({
      query: () => "/users",
    }),
    registerUser: builder.mutation({
      query: (userData) => ({
        url: '/auth/register', // Adjust with your registration endpoint
        method: 'POST',
        body: userData,
      }),
    }),
    userLogin: builder.mutation({
      query: (userData) => ({
        url: '/auth/login', // Adjust with your login endpoint
        method: 'POST',
        body: userData,
      }),
    }),
  }),
});

export const { useGetUsersQuery, useRegisterUserMutation, useUserLoginMutation } = apiSlice;
