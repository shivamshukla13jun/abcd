export const initalLoadData = {
  loadDetails: {
    loadNumber: '',
    loadAmount: '',
    status: '',
    commodity: '',
    loadSize: '',
    declaredValue: '',
    weight: '',
    temperature: '',
    equipmentType: '',
    equipmentLength: '',
    notes: '',
  },
  customerInformation: {
    company: "",
    customerName: "",
    email: "",
    phone: "",
    ext: "",
    fax: "",
    address: "",
    reference: "",
    mcNumber: "",
    usdot: "",
  },
  assetInfo: [
    {
      mcNumber: "",
      usdot: "",
      address: "",
      primaryContact: "",
      contactEmail: "",
      driverInfo: {
        driver1Name: "",
        driver2Name: "",
        driver1Phone: "",
        driver2Phone: "",
        driver1CDL: "",
        driver2CDL: "",
        driver1CDLExpiration: "",
        driver2CDLExpiration: "",
        powerunit: "",
        trailer: "",
      },
    },
  ],
  deliveryLocations: [
    {
      type: "delivery",
      requirements: [],
      address: "",
      state: "",
      city: "",
      zipcode: "",
      locationClass: "",
      date: "",
      time: "",
      notes: "",
    },
  ],
  pickupLocations: [
    {
      type: "pickup",
      requirements: [],
      showPickup: true,
      address: "",
      state: "",
      city: "",
      zipcode: "",
      locationClass: "",
      date: "",
      time: "",
      notes: "",
    },
  ],
  documentUpload: {
    files: [],
    items: [
      {
        id: 1,
        itemDetails: '',
        description: '',
        qty: 1,
        rate: 0,
        discount: 0,
        tax: 0,
        amount: 0,
      },
    ],
    freightCharge: 'Prepaid',
  },
  id: null,
  activeTab: "load",
  showCustomer: false,
  showAsset: false,
  showDriver: false,
  showPickup: false,
  showDelivery: false,
};

export const initialLoadetails = initalLoadData.loadDetails;
export const initialCustomerInformation = initalLoadData.customerInformation;
export const initialAssetInfo = initalLoadData.assetInfo[0];
export const initialDeliveryLocations = initalLoadData.deliveryLocations[0];
export const initialPickupLocations = initalLoadData.pickupLocations[0];  
export const initialDocumentUpload = initalLoadData.documentUpload;