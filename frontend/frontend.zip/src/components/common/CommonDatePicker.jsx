// components/CustomDatePicker.jsx
import React from "react";
import DatePicker from 'react-date-picker';
import TimePicker from 'react-time-picker';
import 'react-date-picker/dist/DatePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import './CustomDatePicker.css';

const CustomDatePicker = ({
    name,
    value,
    readOnly = false,
    onChange,
    required = false,
    placeholder = "Select Date/Time",
    minDate,
    maxDate,
    isTimePicker = false,
    className = "form-control"
}) => {
    const handleChange = (date) => {
        if (!date) {
            onChange({ target: { name, value: "" } });
            return;
        }

        const formattedValue = isTimePicker 
            ? date
            : date.toISOString().split('T')[0];

        onChange({
            target: { 
                name,
                value: formattedValue
            }
        });
    };

    const PickerComponent = isTimePicker ? TimePicker : DatePicker;

    return (
        <div className="custom-datepicker-wrapper">
            <PickerComponent
                onChange={handleChange}
                value={value ? new Date(isTimePicker ? `1970-01-01T${value}` : value) : null}
                format={isTimePicker ? "HH:mm" : "yyyy-MM-dd"}
                disabled={readOnly}
                minDate={minDate}
                maxDate={maxDate}
                required={required}
                className={className}
                clearIcon={null}
                calendarIcon={null}
                openCalendarOnFocus={true}
                disableCalendar={false}
                showLeadingZeros={true}
                dayPlaceholder="dd"
                monthPlaceholder="mm"
                yearPlaceholder="yyyy"
            />
        </div>
    );
};

export default CustomDatePicker;
