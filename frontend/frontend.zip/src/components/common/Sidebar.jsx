import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Nav } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import { FaChevronDown, FaChevronRight, FaChevronLeft, FaBars } from "react-icons/fa";
import { navData } from "@data/navData";
import { toggleSidebar } from "@redux/Slice/sidebarSlice";
import * as FaIcons from "react-icons/fa";
import { logout } from "@redux/Slice/UserSlice";
import "./Sidebar.scss";

const Sidebar = () => {
  const collapsed = useSelector((state) => state.sidebar.collapsed);
  const dispatch = useDispatch();
  const location = useLocation();
  const [openMenus, setOpenMenus] = useState({});

  const handleMenuClick = (event, index, item) => {
    if (item.children) {
      event.preventDefault();
      setOpenMenus((prevState) => ({
        ...prevState,
        [index]: !prevState[index],
      }));
    }
  };

  return (
    <div
      className={`sidebar-bg sidebar-text ${
        collapsed ? "sidebar-collapsed" : "sidebar-expanded"
      }`}
      style={{
        width: collapsed ? "80px" : "250px",
        height: "100vh",
        position: "fixed",
        transition: "all 0.3s ease-in-out",
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-start",
        overflow: "hidden",
        boxShadow: "2px 0 10px rgba(0,0,0,0.1)",
        zIndex: 1000,
        backgroundColor: "#1a237e",
        color: "#fff",
      }}
    >
      <div className="d-flex align-items-center p-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
        {!collapsed && (
          <div className="me-auto" style={{ fontSize: "1.2rem", fontWeight: "bold", color: "#fff" }}>
            Dashboard
          </div>
        )}
        <button
          className="toggle-btn"
          onClick={() => dispatch(toggleSidebar())}
          style={{
            border: "none",
            background: "transparent",
            padding: "8px",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            transition: "all 0.3s ease",
            marginLeft: collapsed ? "auto" : "0",
            marginRight: collapsed ? "auto" : "0",
          }}
        >
          {collapsed ? <FaBars size={20} /> : <FaChevronLeft size={20} />}
        </button>
      </div>

      <Nav className="flex-column py-2" style={{ flex: 1, overflowY: "auto" }}>
        {navData.map((item, index) => (
          <div key={index} className="nav-item-container">
            <Nav.Item className="d-flex align-items-center">
              <Link
                to={item.children ? "#" : item.path}
                className={`nav-link d-flex align-items-center ${
                  location.pathname === item.path ? "active" : ""
                }`}
                onClick={(e) => handleMenuClick(e, index, item)}
                style={{
                  padding: "12px 20px",
                  color: "#fff",
                  opacity: "0.8",
                  transition: "all 0.3s ease",
                  width: "100%",
                  borderRadius: "8px",
                  margin: "2px 8px",
                  ":hover": {
                    opacity: 1,
                    backgroundColor: "rgba(255,255,255,0.1)",
                  }
                }}
              >
                <span className="me-3" style={{ width: "20px", textAlign: "center" }}>
                  {FaIcons[item.icon] && React.createElement(FaIcons[item.icon])}
                </span>
                {!collapsed && <span style={{ whiteSpace: "nowrap" }}>{item.title}</span>}
                {item.children && !collapsed && (
                  <FaChevronDown
                    className="ms-auto"
                    style={{
                      transform: openMenus[index] ? "rotate(180deg)" : "rotate(0)",
                      transition: "transform 0.3s ease"
                    }}
                  />
                )}
              </Link>
            </Nav.Item>

            {item.children && openMenus[index] && !collapsed && (
              <Nav className="flex-column submenu">
                {item.children.map((subItem, subIndex) => (
                  <Nav.Item key={subIndex}>
                    <Link
                      to={subItem.path}
                      className={`nav-link ${
                        location.pathname === subItem.path ? "active" : ""
                      }`}
                      style={{
                        padding: "8px 20px 8px 53px",
                        color: "#fff",
                        opacity: "0.7",
                        fontSize: "0.9rem",
                        transition: "all 0.3s ease",
                        ":hover": {
                          opacity: 1,
                          backgroundColor: "rgba(255,255,255,0.1)",
                        }
                      }}
                    >
                      {subItem.title}
                    </Link>
                  </Nav.Item>
                ))}
              </Nav>
            )}
          </div>
        ))}
      </Nav>

      <Nav className="flex-column border-top" style={{ borderTop: "1px solid rgba(255,255,255,0.1)", padding: "16px 0" }}>
        <Nav.Item>
          <Link
            to="/settings"
            className={`nav-link d-flex align-items-center ${
              location.pathname === "/settings" ? "active" : ""
            }`}
            style={{
              padding: "12px 20px",
              color: "#fff",
              opacity: "0.8",
              transition: "all 0.3s ease",
              margin: "2px 8px",
              borderRadius: "8px",
              ":hover": {
                opacity: 1,
                backgroundColor: "rgba(255,255,255,0.1)",
              }
            }}
          >
            <span className="me-3" style={{ width: "20px", textAlign: "center" }}>
              <FaIcons.FaCog />
            </span>
            {!collapsed && <span>Settings</span>}
          </Link>
        </Nav.Item>
        <Nav.Item>
          <Link
            onClick={() => dispatch(logout())}
            to="#"
            className="nav-link d-flex align-items-center"
            style={{
              padding: "12px 20px",
              color: "#fff",
              opacity: "0.8",
              transition: "all 0.3s ease",
              margin: "2px 8px",
              borderRadius: "8px",
              ":hover": {
                opacity: 1,
                backgroundColor: "rgba(255,255,255,0.1)",
              }
            }}
          >
            <span className="me-3" style={{ width: "20px", textAlign: "center" }}>
              <FaIcons.FaSignOutAlt />
            </span>
            {!collapsed && <span>Logout</span>}
          </Link>
        </Nav.Item>
      </Nav>
    </div>
  );
};

export default Sidebar;
