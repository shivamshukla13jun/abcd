import React, { useState } from 'react';
import { Modal, Form, Button, Row, Col } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import apiService from '@service/apiService';
import './AddCustomer.scss';

const schema = yup.object().shape({
  customerName: yup.string().required('Company name is required'),
  type: yup.string().required('Type is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  phone: yup.string().required('Phone is required'),
  address: yup.string().required('Address is required'),
  city: yup.string().required('City is required'),
  state: yup.string().required('State is required'),
  zipCode: yup.string().required('Zip code is required'),
  mcNumber: yup.string().required('MC Number is required').length(6, 'MC Number must be 6 characters'),
  usdot: yup.string().required('USDOT Number is required'),
  paymentMethod: yup.string().required('Payment method is required'),
  paymentTerms: yup.string().required('Payment terms are required'),
  creditLimit: yup.number().typeError('Credit limit must be a number').required('Credit limit is required'),
  vatNumber: yup.string().required('VAT Registration Number is required'),
  utrNumber: yup.string().required('UTR number is required'),
});

const PAYMENT_METHODS = [
  { value: 'card', label: 'Card' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'cash', label: 'Cash' },
  { value: 'check', label: 'Check' }
];

const PAYMENT_TERMS = [
  { value: 'net_30', label: 'Net 30' },
  { value: 'net_15', label: 'Net 15' },
  { value: 'net_7', label: 'Net 7' },
  { value: 'due_on_receipt', label: 'Due on Receipt' }
];

const AddCustomer = ({ show, onHide, onSuccess }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      customerName: '',
      type: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      mcNumber: '',
      usdot: '',
      notes: '',
      paymentMethod: '',
      paymentTerms: '',
      creditLimit: '',
      vatNumber: '',
      utrNumber: '',
    }
  });

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const onSubmit = async (data) => {
    try {
      setIsSubmitting(true);
      const formData = new FormData();
      Object.keys(data).forEach(key => {
        formData.append(key, data[key]);
      });
      if (selectedFile) {
        formData.append('attachment', selectedFile);
      }
      await apiService.createCustomer(formData);
      onSuccess();
      onHide();
      reset();
      setSelectedFile(null);
    } catch (error) {
      console.error('Error creating customer:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal show={show} onHide={onHide} size="lg" centered className="add-customer-modal">
      <Modal.Header closeButton>
        <Modal.Title>Add New Customer</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <div className="section">
            <h6>Name and Contact</h6>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Company Name</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('customerName')}
                    isInvalid={!!errors.customerName}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.customerName?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Type</Form.Label>
                  <Form.Select
                    {...register('type')}
                    isInvalid={!!errors.type}
                  >
                    <option value="">Select Type</option>
                    <option value="Customer">Customer</option>
                    <option value="Shipper">Shipper</option>
                    <option value="Consignee">Consignee</option>
                    <option value="Broker">Broker</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.type?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    {...register('email')}
                    isInvalid={!!errors.email}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.email?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Phone</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('phone')}
                    isInvalid={!!errors.phone}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.phone?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={12}>
                <Form.Group className="mb-3">
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('address')}
                    isInvalid={!!errors.address}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.address?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>City</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('city')}
                    isInvalid={!!errors.city}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.city?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>State</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('state')}
                    isInvalid={!!errors.state}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.state?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Zip Code</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('zipCode')}
                    isInvalid={!!errors.zipCode}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.zipCode?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
          </div>

          <div className="section">
            <h6>Notes and Attachments</h6>
            <Form.Group className="mb-3">
              <Form.Label>Notes</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                {...register('notes')}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Attachments</Form.Label>
              <div className="attachment-drop-zone">
                <input
                  type="file"
                  onChange={handleFileChange}
                  className="d-none"
                  id="fileInput"
                />
                <div className="text-center p-4 border rounded">
                  <i className="fas fa-cloud-upload-alt mb-2"></i>
                  <p className="mb-0">Choose a file or drag & drop it here</p>
                  <Button
                    variant="outline-primary"
                    size="sm"
                    className="mt-2"
                    onClick={() => document.getElementById('fileInput').click()}
                  >
                    Browse File
                  </Button>
                </div>
                {selectedFile && (
                  <div className="selected-file mt-2">
                    <span>{selectedFile.name}</span>
                    <Button
                      variant="link"
                      className="text-danger p-0 ms-2"
                      onClick={() => setSelectedFile(null)}
                    >
                      Remove
                    </Button>
                  </div>
                )}
              </div>
            </Form.Group>
          </div>

          <div className="section">
            <h6>Accounting Payments</h6>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Primary Payment Method</Form.Label>
                  <Form.Select
                    {...register('paymentMethod')}
                    isInvalid={!!errors.paymentMethod}
                  >
                    <option value="">Select payment method</option>
                    {PAYMENT_METHODS.map(method => (
                      <option key={method.value} value={method.value}>
                        {method.label}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.paymentMethod?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Payment Terms</Form.Label>
                  <Form.Select
                    {...register('paymentTerms')}
                    isInvalid={!!errors.paymentTerms}
                  >
                    <option value="">Select payment terms</option>
                    {PAYMENT_TERMS.map(term => (
                      <option key={term.value} value={term.value}>
                        {term.label}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.paymentTerms?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col md={12}>
                <Form.Group className="mb-3">
                  <Form.Label>Credit Limit</Form.Label>
                  <Form.Control
                    type="number"
                    {...register('creditLimit')}
                    isInvalid={!!errors.creditLimit}
                    placeholder="Enter this customer's credit limit"
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.creditLimit?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
          </div>

          <div className="section">
            <h6>Additional Info</h6>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>MC Number</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('mcNumber')}
                    isInvalid={!!errors.mcNumber}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.mcNumber?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>USDOT Number</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('usdot')}
                    isInvalid={!!errors.usdot}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.usdot?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>VAT Registration Number</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('vatNumber')}
                    isInvalid={!!errors.vatNumber}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.vatNumber?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>UTR Number</Form.Label>
                  <Form.Control
                    type="text"
                    {...register('utrNumber')}
                    isInvalid={!!errors.utrNumber}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.utrNumber?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
          </div>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button
          variant="primary"
          onClick={handleSubmit(onSubmit)}
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Creating...' : 'Create Customer'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AddCustomer;
