import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IoIosAdd, IoIosTrash } from "react-icons/io";
import { addCarierLocation, setAssetInfo, toggleassetInfoVisibility } from "@redux/Slice/EditloadSlice";
import apiService from "@service/apiService";
import CustomDatePicker from "@components/common/CommonDatePicker";
import { initalLoadData, initialAssetInfo } from "@redux/InitialData/Load";
import { taransformCarrierData } from "@utils/transformData";

const Asset = ({ index,onRemove }) => {
  const dispatch = useDispatch();
  const assetInfo = useSelector((state) => state.editload.assetInfo[index]);
  const [carriers, setCarriers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  // Fetch carriers from API
  const fetchCarriers = async () => {
    try {
      const response = await apiService.getCarriers();
      setCarriers(response.data);
    } catch (err) {
      console.error("Error fetching carriers:", err);
    }
  };

  const fetchCarriersByUSDOT = async (usdot) => {
    try {
      const response = await apiService.getDataByUsdotNumber(usdot);
      const transformedCarrierData = taransformCarrierData(response.data);
      dispatch(setAssetInfo({ index, asset: transformedCarrierData }));
    } catch (err) {
      console.error("Error fetching carriers by USDOT:", err);
    }
  };

  useEffect(() => {
    fetchCarriers();
  }, []);

  // Handle Carrier Selection
  const handleCarrierChange = async (e) => {
    const selectedCarrierId = e.target.value;
    
    if (selectedCarrierId && selectedCarrierId !== "") {
      try {
        const response = await apiService.getCarrier(selectedCarrierId);
        dispatch(setAssetInfo({ index, asset: response.data }));
      } catch (err) {
        console.error("Error fetching carrier data:", err);
      }
    } else if (selectedCarrierId === "") {
      dispatch(setAssetInfo({ index, asset: initialAssetInfo }));
      
    }
  };

  const handleUSDOTChange = async (e) => {
    const usdot = e.target.value;
    if (usdot) {
      await fetchCarriersByUSDOT(usdot);
    }
  };
  // Handle Input Change
  const handleChange = (e) => {
    const { name, value } = e.target;
    dispatch(setAssetInfo({ index, asset: { ...assetInfo, [name]: value } }));
  };
 
  const addNewCarier = (data) => {
    dispatch(setAssetInfo({ index, asset:initialAssetInfo }));
  };

  return (

    <div className="pickup-location-container mb-4 p-3 border rounded">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6>Carrier {index + 1}</h6>
            {onRemove && (
              <button
                type="button"
                className="btn btn-sm btn-outline-danger"
                onClick={() => onRemove(index)}
              >
                <IoIosTrash /> Remove
              </button>
            )}
          </div>
      <div className="form-group row">
        <div className="col-sm-12">
          <input
            type="text"
            className="form-control"
            placeholder="Search by USDOT Number"
            onChange={handleUSDOTChange}
          />
        </div>
      </div>
    
      <div className="form-group row">
        <div className="col-sm-12">
          <select className="form-control" onChange={handleCarrierChange} value={assetInfo?._id || ""}>
            <option disabled value="">
              Select Carrier
            </option>
            {carriers
              .filter((carrier) => carrier.primaryContact.toLowerCase().includes(searchTerm.toLowerCase()))
              .map((carrier) => (
                <option key={carrier._id} value={carrier._id}>{"Carrier "+carrier.primaryContact}</option>
              ))}
          </select>
          <p  onClick={addNewCarier} className="create-link">
            <IoIosAdd  /> Click here to create a new Carrier to add to this load.
          </p>
        </div>
      </div>

     
        <>
          <div className="form-group row">
            <div className="col-sm-3">
            <label className="form-label">MC#</label>
              <input
                type="text"
                readOnly={true}
                className="form-control"
                placeholder="MC#"
                name="mcNumber"
                value={assetInfo?.mcNumber || ""}
                onChange={handleChange}
                
              />
            </div>
            <div className="col-sm-3">
            <label className="form-label">USDOT Number</label>
              <input
                type="text"
                readOnly={true}
                className="form-control"
                placeholder="USDOT Number"
                name="usdot"
                value={assetInfo?.usdot || ""}
                onChange={handleChange}
                
              />
            </div>
            <div className="col-sm-6">
            <label className="form-label">Address</label>
              <input
                type="text"
                readOnly={true}
                className="form-control"
                placeholder="Address"
                name="address"
                value={assetInfo?.address || ""}
                onChange={handleChange}
                
              />
            </div>
          </div>

          <div className="form-group row mt-5">
            
            <div className="col-sm-3">
            <label className="form-label">Primary Contact</label>
              <input
                type="text"
                readOnly={true}
                className="form-control"
                placeholder="Primary Contact"
                name="primaryContact"
                value={assetInfo?.primaryContact || ""}
                onChange={handleChange}
                
              />
            </div>
            <div className="col-sm-3">
            <label className="form-label">Contact Email</label>
              <input
                type="email"
                // readOnly={true}
                className="form-control"
                placeholder="Contact Email"
                name="contactEmail"
                value={assetInfo?.contactEmail || ""}
                onChange={handleChange}
                
              />
            </div>
          </div>
          <>
      <div className="form-group row">
        <div className="col-sm-12">
          <h6 className="section-title mb-3">Driver</h6>
          
        </div>
      </div>

        <div>
          {[1, 2].map((num) => (
            <div className="form-group row mb-4" key={num}>
              <div className="col-sm-3">
                <label className="form-label">Driver {num}</label>
                <input
                  type="text"
                  // readOnly={true}
                  className="form-control"
                  placeholder={`Driver ${num} Name`}
                  name={`driver${num}Name`}
                  value={assetInfo?.[`driver${num}Name`] || ""}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-sm-3">
                <label className="form-label">Driver {num} Phone</label>
                <input
                  type="number"
                  // readOnly={true}
                  className="form-control"
                  placeholder={`Driver ${num} Phone`}
                  name={`driver${num}Phone`}
                  value={assetInfo?.[`driver${num}Phone`] || ""}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-sm-3">
                <label className="form-label">CDL Number</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="CDL Number"
                  // readOnly={true}
                  name={`driver${num}CDL`}
                  value={assetInfo?.[`driver${num}CDL`] || ""}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-sm-3">
                <label className="form-label">CDL Expiration</label>
                <CustomDatePicker
                  type="date"
                  className="form-control"
                  name={`driver${num}CDLExpiration`}
                  value={assetInfo?.[`driver${num}CDLExpiration`] || ""}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          ))}
          <hr />
          <div className="form-group row">
            <div className="col-sm-6">
              <label className="form-label">Power Unit</label>
              <input
                type="text"
                className="form-control"
                placeholder="Power Unit"
                name="powerunit"
                // readOnly={true}
                value={assetInfo?.powerunit || ""}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-sm-6">
              <label className="form-label">Trailer</label>
              <input
                type="text"
                className="form-control"
                placeholder="Trailer"
                name="trailer"
                // readOnly={true}
                value={assetInfo?.trailer || ""}
                onChange={handleChange}
                required
              />
            </div>
          </div>
        </div>
      
    </>

        </>
      
    </div>
  );
};

export default Asset;
