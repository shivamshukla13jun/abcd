import { Sequelize, QueryTypes } from 'sequelize';

async function resetDatabase(sequelize: Sequelize) {
  try {
    // Disable foreign key checks
    await sequelize.query('SET FOREIGN_KEY_CHECKS = 0;');

    // Get all tables in the database
    const tables = await sequelize.query(
      `SELECT TABLE_NAME as tableName 
       FROM INFORMATION_SCHEMA.TABLES 
       WHERE TABLE_SCHEMA = DATABASE()`,
      { type: QueryTypes.SELECT }
    );

    // Drop all tables
    for (const { tableName } of tables as { tableName: string }[]) {
      await sequelize.query(`DROP TABLE IF EXISTS \`${tableName}\``);
      console.log(`Dropped table: ${tableName}`);
    }

    // Re-enable foreign key checks
    await sequelize.query('SET FOREIGN_KEY_CHECKS = 1;');
    
    console.log('All tables dropped successfully');
    
    // Recreate all tables
    await sequelize.sync({ force: true });
    console.log('Database synchronized with new schema');
    
  } catch (error) {
    // Make sure to re-enable foreign key checks even if there's an error
    await sequelize.query('SET FOREIGN_KEY_CHECKS = 1;')
      .catch(err => console.error('Error re-enabling foreign key checks:', err));
      
    console.error('Error during database reset:', error);
    throw error;
  }
}

export default resetDatabase;