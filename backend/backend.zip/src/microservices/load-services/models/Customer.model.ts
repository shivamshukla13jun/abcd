import mongoose, { Schema, Document, model } from 'mongoose';

interface ICustomer extends Document {
  company: string;
  customerName: string;
  email: string;
  phone: string;
  ext: string;
  fax: string;
  address: string;
  referenceNumber?: string;
  mcNumber: string;
  usdot: string;
  userId: mongoose.Types.ObjectId;
  ratings?: number;
}

const CustomerSchema: Schema = new Schema({
  company: { type: String, required: true },
  customerName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  ext: { type: String, default: "" },
  fax: { type: String, default: "" },
  address: { type: String, required: true },
  referenceNumber: { type: String },
  mcNumber: { type: String, required: true, unique: true, length: 6 },
  usdot: { type: String, required: true, unique: true },
  userId: { type: mongoose.Types.ObjectId, ref: 'User', required: true },
  ratings: { type: Number, default: 0 },
}, { timestamps: true });
// oN DUPLICATER FIELD SEND CUSTOME ERROR MESSAGE AND CUSTOME PROPERTY FILELD

export default model<ICustomer>('Customer', CustomerSchema);
