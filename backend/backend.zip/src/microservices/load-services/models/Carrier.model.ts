import mongoose, { Schema, Document, model } from 'mongoose';

interface ICarrier extends Document {
  mcNumber: string;
  usdot: string;
  address: string;
  primaryContact: string;
  duns_number ? : string;
  contactEmail: string;
  legal_name ? : string;
  drivers ? :number;
  safety_rating_date ? : number;
  safety_review_date ? : number;
  safety_rating ? : number;
  safety_type ? : number;
  latest_update ? : Date;
  userId: mongoose.Types.ObjectId;
  loads: mongoose.Types.ObjectId[];
  driver1Name: string;
  driver1Phone: string;
  driver1CDL: string;
  driver1CDLExpiration: Date;
  driver2Name: string;
  driver2Phone: string;
  driver2CDL: string;
  driver2CDLExpiration: Date;
  powerunit: string;
  trailer: string;
}

const CarrierSchema: Schema = new Schema({
  mcNumber: { type: String, required: true },
  usdot: { type: String, required: true },
  address: { type: String, required: true },
  primaryContact: { type: String, required: true },
  legal_name: { type: String, required: false },
  duns_number: { type: String, required: false },
  drivers: { type: Number, required: false ,default: 0},
  safety_rating_date: { type: Number, required: false },
  safety_review_date: { type: Number, required: false },
  safety_rating: { type: Number, required: false },
  safety_type: { type: Number, required: false },
  latest_update: { type: Date, required:false
  },

  contactEmail: { type: String, required: true },
  userId: { type: mongoose.Types.ObjectId, ref: 'User', required: true },
  loads: [{ type: mongoose.Types.ObjectId, ref: 'Load' }],
  driver1Name: { type: String, required: true },
  driver1Phone: { type: String, required: true },
  driver1CDL: { type: String, required: true },
  driver1CDLExpiration: { type: Date, required: true },
  driver2Name: { type: String, required: true },
  driver2Phone: { type: String, required: true },
  driver2CDL: { type: String, required: true },
  driver2CDLExpiration: { type: Date, required: true },
  powerunit: { type: String, required: true },
  trailer: { type: String, required: true },
}, { timestamps: true });

export default model<ICarrier>('Carrier', CarrierSchema);
