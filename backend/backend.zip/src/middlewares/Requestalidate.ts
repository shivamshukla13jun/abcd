import { Request, Response, NextFunction } from 'express';
import { AnySchema } from 'yup';
import { AppError } from './error';

const requestValidate = (schema: AnySchema) => async (req: Request, res: Response, next: NextFunction) => {
  try {
  
    req.body = await schema.validate(req.body, { abortEarly: false, stripUnknown: true });
    next();
  } catch (err: any) {
    next(err);
  }
};

export default requestValidate;
