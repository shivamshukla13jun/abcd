import { Request, Response, NextFunction } from "express";
import { JsonWebTokenError, TokenExpiredError } from "jsonwebtoken";
import { ValidationError as YupValidationError } from "yup";
import { 
  SequelizeScopeError,
  ValidationError as SequelizeValidationError, 
  UniqueConstraintError 
} from "sequelize";

// Custom error class
class AppError extends Error {
  statusCode: number;
  isOperational: boolean;

  constructor(message: string, statusCode: number) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

// Not Found middleware
const notFound = (req: Request, res: Response, next: NextFunction) => {
  const error = new AppError(`Not Found - ${req.originalUrl}`, 404);
  next(error);
};

// Global error handler
const errorHandler = (
  err: Error | AppError | JsonWebTokenError | YupValidationError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.log(err)
  let error = { ...err };

  // If error already is an AppError, use it directly
  if ('statusCode' in err && 'isOperational' in err) {
    return res.status((err as AppError).statusCode).json({
      success: false,
      message: err.message,
      stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
    });
  }

  // Handle Sequelize unique constraint error
  if (err instanceof UniqueConstraintError) {
    error = new AppError("Duplicate field value entered", 400);
  }
  if (err.message === 'Not allowed by CORS') {
    throw new AppError("You are not allowed to access this resource",403)
   } 
  // Handle Sequelize validation errors
  if (err instanceof SequelizeValidationError) {
    const messages = err.errors.slice(0,1).map((e: any) => e.message).join(", ");
    error = new AppError(messages, 400);
  }
  if(err  instanceof SequelizeScopeError){
    const messages = err.message
    
    error = new AppError(messages, 400);
  }

  // Handle JWT errors
  if (err instanceof JsonWebTokenError || err instanceof TokenExpiredError) {
    error = new AppError("Invalid or expired token", 401);
  }

  // Handle Yup validation errors
  if (err instanceof YupValidationError) {
    const messages = err.errors.join(", ");
    error = new AppError(messages, 400);
  }

  // Fallback for other errors
  if (!(error instanceof AppError)) {
    error = new AppError(error.message || "Internal Server Error", 500);
  }

  res.status((error as AppError).statusCode).json({
    success: false,
    message: (error as AppError).message,
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
  });
};

export { notFound, errorHandler, AppError };
